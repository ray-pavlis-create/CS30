#dice game
import random
min = 1
max = 6

roll_again = "yes"

print ("Dice Roll Simulator :)")
while roll_again == "yes" or roll_again == "y":
  print("rolling the dice.....")
  print("you got:")
  print (random.randint(min, max))
  print (random.randint(min, max))
  
  reroll = input("roll dice again? y or n: ")
  if reroll == "y":
    roll_again = "yes"
  elif reroll == "n":
    roll_again == "no"
    print ("goodbye :)")
    break